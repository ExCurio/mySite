def purpleFilter():
  myFile = pickAFile()
  myPic = makePicture(myFile)
  show(myPic)
  reduceBlue(myPic)
  reduceGreen(myPic)
  repaint(myPic)
  
def reduceBlue(myPic):
  for pixel in getPixels(myPic):
    value=getBlue(pixel)
    setBlue(pixel,value*0.7)
    
def reduceGreen(myPic):
  for pixel in getPixels(myPic):    
    value=getGreen(pixel)
    setGreen(pixel,value*0.7)